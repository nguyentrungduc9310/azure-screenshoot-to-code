import copy
from enum import Enum
import base64
import time
from typing import Any, Awaitable, Callable, List, cast, TypedDict

from openai import AsyncOpenAI, AsyncAzureOpenAI
from openai.types.chat import ChatCompletionMessageParam, ChatCompletionChunk
from anthropic import AsyncAnthropic
from config import IS_DEBUG_ENABLED
from debug.DebugFileWriter import DebugFileWriter
from image_processing.utils import process_image
from google import genai
from google.genai import types

from utils import pprint_prompt

# Actual model versions that are passed to the LLMs and stored in our logs
class Llm(Enum):
    GPT_4_VISION = "gpt-4-vision-preview"
    GPT_4_TURBO_2024_04_09 = "gpt-4-turbo-2024-04-09"
    GPT_4O_2024_05_13 = "gpt-4o-2024-05-13"
    GPT_4O_2024_08_06 = "gpt-4o-2024-08-06"
    GPT_4O_2024_11_20 = "gpt-4o-2024-11-20"
    GPT_5_MINI = "gpt-5-mini"
    CLAUDE_3_SONNET = "claude-3-sonnet-20240229"
    CLAUDE_3_OPUS = "claude-3-opus-20240229"
    CLAUDE_3_HAIKU = "claude-3-haiku-20240307"
    CLAUDE_3_5_SONNET_2024_06_20 = "claude-3-5-sonnet-20240620"
    CLAUDE_3_5_SONNET_2024_10_22 = "claude-3-5-sonnet-20241022"
    GEMINI_2_0_FLASH_EXP = "gemini-2.0-flash-exp"
    O1_2024_12_17 = "o1-2024-12-17"

class Completion(TypedDict):
    duration: float
    code: str

async def stream_openai_response(
    messages: List[ChatCompletionMessageParam],
    api_key: str,
    base_url: str | None,
    callback: Callable[[str], Awaitable[None]],
    model: Llm,
    *,
    azure_api_version: str | None = None,
    resource_name: str | None = None,
    deployment_name: str | None = None,
) -> Completion:
    """
    Stream response từ OpenAI, có hỗ trợ dùng Azure OpenAI nếu cung cấp đầy đủ:
      - azure_api_version
      - resource_name
      - deployment_name

    Các tham số:
      - messages: danh sách các ChatCompletionMessageParam.
      - api_key: API key dùng cho OpenAI hoặc Azure.
      - base_url: base_url của OpenAI (đối với trường hợp không dùng Azure).
      - callback: hàm callback nhận từng đoạn text khi stream.
      - model: instance của Llm để xác định model cần sử dụng.
      - azure_api_version, resource_name, deployment_name: nếu được cung cấp,
          sẽ khởi tạo client AsyncAzureOpenAI thay vì AsyncOpenAI.
    """
    start_time = time.time()
    # Nếu thông tin Azure được cung cấp đầy đủ, dùng AsyncAzureOpenAI
    if azure_api_version and resource_name and deployment_name:
        client = AsyncAzureOpenAI(
            api_version=azure_api_version,
            api_key=api_key,
            azure_endpoint=f"https://{resource_name}.openai.azure.com/",
            azure_deployment=deployment_name,
        )
    else:
        client = AsyncOpenAI(api_key=api_key, base_url=base_url)

    # Base parameters cho việc gọi API
    params: dict[str, Any] = {
        "model": model.value,
        "messages": messages,
        "timeout": 600,
    }

    # Cài đặt các tham số phụ thuộc vào model
    if model not in (Llm.O1_2024_12_17, Llm.GPT_5_MINI):
        params["temperature"] = 0
        params["stream"] = True

    if model == Llm.GPT_4O_2024_05_13:
        params["max_tokens"] = 4096

    if model == Llm.GPT_4O_2024_11_20:
        params["max_tokens"] = 16384

    if model == Llm.O1_2024_12_17:
        params["max_completion_tokens"] = 20000

    if model == Llm.GPT_5_MINI:
        params["max_completion_tokens"] = 16384

    # Nếu model O1 hoặc GPT-5-mini không hỗ trợ streaming, gọi API theo kiểu blocking
    if model in (Llm.O1_2024_12_17, Llm.GPT_5_MINI):
        response = await client.chat.completions.create(**params)  # type: ignore
        full_response = response.choices[0].message.content  # type: ignore
        await callback(full_response)
    else:
        stream = await client.chat.completions.create(**params)  # type: ignore
        full_response = ""
        async for chunk in stream:  # type: ignore
            assert isinstance(chunk, ChatCompletionChunk)
            if (
                chunk.choices
                and len(chunk.choices) > 0
                and chunk.choices[0].delta
                and chunk.choices[0].delta.content
            ):
                content = chunk.choices[0].delta.content or ""
                full_response += content
                await callback(content)

    await client.close()
    completion_time = time.time() - start_time
    return {"duration": completion_time, "code": full_response}


# TODO: Have a separate function that translates OpenAI messages to Claude messages
async def stream_claude_response(
    messages: List[ChatCompletionMessageParam],
    api_key: str,
    callback: Callable[[str], Awaitable[None]],
    model: Llm,
) -> Completion:
    start_time = time.time()
    client = AsyncAnthropic(api_key=api_key)

    # Base parameters
    max_tokens = 8192
    temperature = 0.0

    # Deep copy messages để không làm thay đổi danh sách gốc
    cloned_messages = copy.deepcopy(messages)
    system_prompt = cast(str, cloned_messages[0].get("content"))
    claude_messages = [dict(message) for message in cloned_messages[1:]]
    for message in claude_messages:
        if not isinstance(message["content"], list):
            continue
        for content in message["content"]:  # type: ignore
            if content["type"] == "image_url":
                content["type"] = "image"
                # Extract base64 data and media type từ data URL
                image_data_url = cast(str, content["image_url"]["url"])
                (media_type, base64_data) = process_image(image_data_url)
                # Loại bỏ tham số OpenAI
                del content["image_url"]
                content["source"] = {
                    "type": "base64",
                    "media_type": media_type,
                    "data": base64_data,
                }

    # Stream Claude response
    async with client.messages.stream(
        model=model.value,
        max_tokens=max_tokens,
        temperature=temperature,
        system=system_prompt,
        messages=claude_messages,  # type: ignore
        extra_headers={"anthropic-beta": "max-tokens-3-5-sonnet-2024-07-15"},
    ) as stream:
        async for text in stream.text_stream:
            await callback(text)

    # Lấy message cuối cùng
    response = await stream.get_final_message()
    await client.close()
    completion_time = time.time() - start_time
    return {"duration": completion_time, "code": response.content[0].text}


async def stream_claude_response_native(
    system_prompt: str,
    messages: list[Any],
    api_key: str,
    callback: Callable[[str], Awaitable[None]],
    include_thinking: bool = False,
    model: Llm = Llm.CLAUDE_3_OPUS,
) -> Completion:
    start_time = time.time()
    client = AsyncAnthropic(api_key=api_key)

    # Base model parameters
    max_tokens = 4096
    temperature = 0.0

    current_pass_num = 1
    max_passes = 2
    prefix = "<thinking>"
    response = None

    # For debugging
    full_stream = ""
    debug_file_writer = DebugFileWriter()

    while current_pass_num <= max_passes:
        current_pass_num += 1
        messages_to_send = (
            messages + [{"role": "assistant", "content": prefix}]
            if include_thinking
            else messages
        )
        pprint_prompt(messages_to_send)

        async with client.messages.stream(
            model=model.value,
            max_tokens=max_tokens,
            temperature=temperature,
            system=system_prompt,
            messages=messages_to_send,  # type: ignore
        ) as stream:
            async for text in stream.text_stream:
                print(text, end="", flush=True)
                full_stream += text
                await callback(text)

        response = await stream.get_final_message()
        response_text = response.content[0].text

        if IS_DEBUG_ENABLED:
            debug_file_writer.write_to_file(
                f"pass_{current_pass_num - 1}.html",
                debug_file_writer.extract_html_content(response_text),
            )
            debug_file_writer.write_to_file(
                f"thinking_pass_{current_pass_num - 1}.txt",
                response_text.split("</thinking>")[0],
            )

        messages += [
            {"role": "assistant", "content": prefix + response.content[0].text},
            {
                "role": "user",
                "content": (
                    "You've done a good job with a first draft. Improve this further based on the original instructions "
                    "so that the app is fully functional and looks like the original video of the app we're trying to replicate."
                ),
            },
        ]

        print(
            f"Token usage: Input Tokens: {response.usage.input_tokens}, Output Tokens: {response.usage.output_tokens}"
        )

    await client.close()
    completion_time = time.time() - start_time

    if IS_DEBUG_ENABLED:
        debug_file_writer.write_to_file("full_stream.txt", full_stream)

    if not response:
        raise Exception("No HTML response found in AI response")
    else:
        return {"duration": completion_time, "code": response.content[0].text}  # type: ignore


async def stream_gemini_response(
    messages: List[ChatCompletionMessageParam],
    api_key: str,
    callback: Callable[[str], Awaitable[None]],
    model: Llm,
) -> Completion:
    start_time = time.time()

    # Extract image URLs từ messages (chỉ lấy ảnh đầu tiên nếu có)
    image_urls = []
    for content_part in messages[-1]["content"]:  # type: ignore
        if content_part["type"] == "image_url":  # type: ignore
            image_url = content_part["image_url"]["url"]  # type: ignore
            if image_url.startswith("data:"):  # type: ignore
                mime_type = image_url.split(";")[0].split(":")[1]  # type: ignore
                base64_data = image_url.split(",")[1]  # type: ignore
                image_urls = [{"mime_type": mime_type, "data": base64_data}]
            else:
                image_urls = [{"uri": image_url}]
            break

    client = genai.Client(api_key=api_key)  # type: ignore
    full_response = ""
    async for response in client.aio.models.generate_content_stream(  # type: ignore
        model=model.value,
        contents={
            "parts": [
                {"text": messages[0]["content"]},  # type: ignore
                types.Part.from_bytes(
                    data=base64.b64decode(image_urls[0]["data"]),  # type: ignore
                    mime_type=image_urls[0]["mime_type"],  # type: ignore
                ),
            ]
        },
        config=types.GenerateContentConfig(
            temperature=0, max_output_tokens=8192
        ),
    ):  # type: ignore
        if response.text:  # type: ignore
            full_response += response.text  # type: ignore
            await callback(response.text)  # type: ignore
    completion_time = time.time() - start_time
    return {"duration": completion_time, "code": full_response}